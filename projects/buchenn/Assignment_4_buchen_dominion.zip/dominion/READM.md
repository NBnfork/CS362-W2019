This is my assignment 4 submission
"make randomAll" to run random test suite on smithy, embargo, and adventurer cards
output: randomtestcard1.out randomtestcard2.out randomtestadventurer.out
