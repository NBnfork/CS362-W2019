//
// Created by noah2017 on 2/10/19.
//

int playCardTestSalvager(struct gameState* mutable);
