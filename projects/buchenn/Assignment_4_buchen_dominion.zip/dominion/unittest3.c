//
// Created by noah2017 on 2/10/19.
int discardCardTest(struct gameState* mutable);
//

