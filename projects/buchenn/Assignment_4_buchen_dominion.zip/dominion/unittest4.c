//
// Created by noah2017 on 2/10/19.
int fullDeckCountTest(struct gameState* mutable);
//

